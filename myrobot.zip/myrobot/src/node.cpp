#include "ros/ros.h"
#include "std_msgs/Float64.h"
#include "sensor_msgs/JointState.h"
#include "hebiros/EntryListSrv.h"
#include "hebiros/AddGroupFromNamesSrv.h"
#include "hebiros/SizeSrv.h"
#include "opencv_apps/FaceArrayStamped.h"
#include <cstdlib> 
#include <iostream> 
#include <array>

using namespace hebiros;


/*
**   Global Variables.  So the callbacks can pass information.
*/
sensor_msgs::JointState feedback;       // The actuator feedback struccture
volatile int            feedbackvalid = 0;
volatile double         goalpos;        // The goal position
volatile double         xpos;
volatile double         prev_face = 0;

/*
**   Feedback Subscriber Callback
*/
void feedbackCallback(sensor_msgs::JointState data)
{
  feedback = data;
  //ROS_INFO("FBK pos [%f]", feedback.position[0]);
  feedbackvalid = 1;
}


/*
**   Goal Subscriber Callback
*/
void goalCallback(const std_msgs::Float64::ConstPtr& msg)
{
  goalpos = msg->data;
  ROS_INFO("I heard: [%f]", (double) msg->data);
}

void faceCallback(const opencv_apps::FaceArrayStamped_<std::allocator<void> >& msg)
{
  //header = msg->header;
  //faces = msg->faces;
  //face1 = faces[0]->face;
 /* if(msg.faces.size() == 0){
    xpos = -1;
  }
*/
  if(msg.faces.size() > 0){
    xpos = (double) msg.faces[0].face.x;
  }
  
  ROS_INFO("I heard: [%f]", xpos);

}

/*
**   Main Code
*/
int main(int argc, char **argv)
{
  // Initialize the basic ROS node, run at 200Hz.
  ros::init(argc, argv, "simple2_node");
  ros::NodeHandle n;
  ros::Rate loop_rate(200);


  // Ask the Hebi node to list the modules.  Create a client to their
  // service, instantiate a service class, and call.  This has no
  // input or output arguments.
  ros::ServiceClient entry_list_client = n.serviceClient<EntryListSrv>("/hebiros/entry_list");
  EntryListSrv entry_list_srv;
  entry_list_client.call(entry_list_srv);

  // Create a new "group of actuators".  This has input arguments,
  // which are the names of the actuators.
  std::string group_name = "all";
  ros::ServiceClient add_group_client = n.serviceClient<AddGroupFromNamesSrv>("/hebiros/add_group_from_names");
  AddGroupFromNamesSrv add_group_srv;
  add_group_srv.request.group_name = group_name;
  add_group_srv.request.names = {"Happy"};
  add_group_srv.request.families = {"134"};
  // Repeatedly call the service until it succeeds.
  while(!add_group_client.call(add_group_srv)) ;

  // Check the size of this group.  This has an output argument.
  ros::ServiceClient size_client = n.serviceClient<SizeSrv>("/hebiros/"+group_name+"/size");
  SizeSrv size_srv;
  size_client.call(size_srv);
  ROS_INFO("%s has been created and has size %d", group_name.c_str(), size_srv.response.size);



  // Create a subscriber to listen for a goal.
  ros::Subscriber goalSubscriber = n.subscribe("goal", 100, goalCallback);
  ros::Subscriber faceSubscriber = n.subscribe("/face_detection/faces", 100000000, faceCallback);

  // Create a subscriber to receive feedback from the actuator group.
  ros::Subscriber feedback_subscriber = n.subscribe("/hebiros/"+group_name+"/feedback/joint_state", 100, feedbackCallback);

  feedback.position.reserve(1);
  feedback.velocity.reserve(1);
  feedback.effort.reserve(1);

  //ros::Subscriber faceSubscriber = n.subscribe("/face_detection/faces", 100000000, faceCallback);

  // Create a publisher to send commands to the actuator group.
  ros::Publisher command_publisher = n.advertise<sensor_msgs::JointState>("/hebiros/"+group_name+"/command/joint_state", 100);

  sensor_msgs::JointState command_msg;
  command_msg.name.push_back("134/Happy");
  command_msg.position.resize(1);
  command_msg.velocity.resize(1);
  command_msg.effort.resize(1);


  // Wait until we have some feedback from the actuator.
  ROS_INFO("Waiting for initial feedback");
  while (!feedbackvalid)
    {
      ros::spinOnce();
      loop_rate.sleep();
    }


  // Prep the servo loop.
  //double  dt = loop_rate.expectedCycleTime().toSec();

  //double  speed = 0.03;          // Speed to reach goal.
  //double  cmdpos = feedback.position[0];
  //double  cmdvel = 0.0;

  // Start where we are.
  //goalpos = cmdpos;

  // Run the servo loop until shutdown.
  //ROS_INFO("Running the servo loop with dt %f", dt);
  int boolean = 0;
  while(ros::ok())
    {
      



      // Move the goal.

      /*if((xpos - 240) < 100)
      {
        goalpos = cmdpos + .1;
      }
      if((xpos - 240) > 100)
      {
        goalpos = cmdpos - .1;
      }

      if      (cmdpos < goalpos - speed*dt)   cmdvel = speed;
      else if (cmdpos > goalpos + speed*dt)   cmdvel = -speed;
      else                                    cmdvel = (goalpos - cmdpos)/dt;

      cmdpos += goalpos;*/

      // info
      //ROS_INFO("Command position [%f]", cmdpos);

      // Apply.
      

      /*if(xpos == -1){
        if(boolean == 0){
          command_msg.position[0] = feedback.position[0] - .1;
          boolean = 1;
          //command_publisher.publish(command_msg);
        }
        else{
          command_msg.position[0] = feedback.position[0] + .1;
          boolean = 0;
          //command_publisher.publish(command_msg);
        }
      }*/
        
        //ros::spinOnce();
      /*else{
        if((xpos - 400) < -50)
        {
          command_msg.position[0] = feedback.position[0] + .1;
        }
        if((xpos - 400) > 50)
        {
          command_msg.position[0] = feedback.position[0] - .1;
        }
      }*/
        
        //ros::spinOnce();
        

      // Wait for next turn.
      
      if((xpos - 300) < -100)
        {
          command_msg.position[0] = feedback.position[0] + .1;
        }
      if((xpos - 300) > 100)
      {
        command_msg.position[0] = feedback.position[0] - .1;
      }
    
      
      
      
      //command_msg.position[0] = cmdpos;
      //command_msg.velocity[0] = cmdvel;
      //command_msg.effort[0]   = 0.0;
      command_publisher.publish(command_msg);

      // Wait for next turn.
      ros::spinOnce();
      //loop_rate.sleep();
      //ros::Duration(0.1).sleep();
    }

  return 0;
}
